# Ace
AceFx
项目使用 .NET Framework4.5 开发，使用 MVC 5.2。使用 Chloe.ORM 作为数据库访问组件，支持SqlServer、MySql、Oracle和SQLite四种数据库随意切换。

有关 Chloe.ORM 介绍：[https://github.com/shuxinqin/Chloe](https://github.com/shuxinqin/Chloe "https://github.com/shuxinqin/Chloe") 感兴趣的记得关注或收藏(star)哦，以便及时收到最新更新通知。

1.自行根据自己安装环境从db文件夹中执行相应的数据库脚本创建相关表（SQLite直接使用Chloe.db）

2.修改Web.config文件中的数据库连接字符串和数据库类型（DbType），即可运行，后台默认登录帐号 admin，密码 52chloe

