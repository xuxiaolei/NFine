﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chloe.Home.Common
{
    public class WebConsts
    {
        public const int PageOutputCacheDuration = 60;
    }
}