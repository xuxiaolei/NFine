﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chloe.Application.Common
{
    public class AppConsts
    {
        const string _AdminUserName = "admin";

        public static string AdminUserName { get { return _AdminUserName; } }
    }
}
