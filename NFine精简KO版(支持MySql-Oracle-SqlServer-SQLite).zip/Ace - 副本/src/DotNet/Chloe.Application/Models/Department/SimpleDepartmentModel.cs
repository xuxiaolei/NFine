﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chloe.Application.Models.Department
{
    public class SimpleDepartmentModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
