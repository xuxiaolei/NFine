﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chloe.Entities.Enums
{
    public enum Gender
    {
        Man = 1,
        Woman = 2,
    }
}
